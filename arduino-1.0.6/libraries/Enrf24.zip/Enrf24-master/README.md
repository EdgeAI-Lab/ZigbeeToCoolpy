Enrf24
======

nRF24L01+ Transceiver Library for Energia, geared for simplicity.